'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'

const skills = [
  { label: 'Next.js', color: 'blue' },
  { label: 'React', color: 'blue' },
  { label: 'Python', color: 'blue' },
  { label: 'JavaScript', color: 'blue' },
  { label: 'UI Design', color: 'purple' },
  { label: 'Database', color: 'purple' },
  { label: 'Figma', color: 'purple' },
  { label: 'Tailwind CSS', color: 'purple' },
  { label: 'Vercel', color: 'cyan' },
  { label: 'Git', color: 'cyan' },
  { label: 'REST API', color: 'cyan' },
]

const colorMap = {
  blue: { border: 'rgba(79,195,247,0.35)', color: '#4FC3F7' },
  purple: { border: 'rgba(157,78,221,0.35)', color: '#9D4EDD' },
  cyan: { border: 'rgba(0,255,209,0.3)', color: '#00FFD1' },
}

const stats = [
  { value: '3+', label: 'Projects Shipped' },
  { value: '2025', label: 'Started Building' },
  { value: '1', label: 'Real Business' },
]

function FadeIn({ children, delay = 0 }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay }}
    >
      {children}
    </motion.div>
  )
}

export default function About() {
  return (
    <section
      id="about"
      className="relative px-8 md:px-24 py-32"
      style={{ borderTop: '0.5px solid rgba(79,195,247,0.1)' }}
    >
      {/* Nebula accent */}
      <div
        className="absolute left-0 top-1/2 pointer-events-none"
        style={{
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(79,195,247,0.05) 0%, transparent 70%)',
          transform: 'translateY(-50%)',
        }}
      />

      <div className="relative z-10 max-w-2xl">

        {/* Label */}
        <FadeIn delay={0}>
          <div className="flex items-center gap-3 mb-3">
            <span
              className="font-mono text-xs tracking-widest uppercase"
              style={{ color: '#00FFD1' }}
            >
              {"// about"}
            </span>
          </div>
          <h2
            className="font-sora font-semibold mb-2"
            style={{ fontSize: '32px', letterSpacing: '-0.01em' }}
          >
            Who I Am
          </h2>
          {/* Divider */}
          <div
            className="mb-8"
            style={{
              width: '40px',
              height: '1px',
              background: 'linear-gradient(90deg, #4FC3F7, #9D4EDD)',
            }}
          />
        </FadeIn>

        {/* Bio */}
        <FadeIn delay={0.1}>
          <p
            className="font-sora font-light mb-4"
            style={{ fontSize: '15px', color: '#6b6b8a', lineHeight: 1.85 }}
          >
            {/* Replace this with your actual bio */}
            Informatika student at Telkom University with a focus on building
            things that actually work in the real world — not just coursework.
            I care about clean interfaces, real use cases, and shipping things
            people can actually use.
          </p>
          <p
            className="font-sora font-light mb-10"
            style={{ fontSize: '15px', color: '#6b6b8a', lineHeight: 1.85 }}
          >
            Outside of code, I run a dimsum business called Bao De Luna —
            and yes, I built the ordering system for it myself.
          </p>
        </FadeIn>

        {/* Stats */}
        <FadeIn delay={0.2}>
          <div className="flex gap-8 mb-12">
            {stats.map(({ value, label }) => (
              <div key={label}>
                <div
                  className="font-sora font-bold mb-1"
                  style={{ fontSize: '28px', color: '#4FC3F7' }}
                >
                  {value}
                </div>
                <div
                  className="font-mono text-xs tracking-wider uppercase"
                  style={{ color: '#6b6b8a' }}
                >
                  {label}
                </div>
              </div>
            ))}
          </div>
        </FadeIn>

        {/* Skills */}
        <FadeIn delay={0.3}>
          <div
            className="font-mono text-xs tracking-widest uppercase mb-4"
            style={{ color: '#6b6b8a' }}
          >
            Tech I work with
          </div>
          <div className="flex flex-wrap gap-2">
            {skills.map(({ label, color }) => (
              <span
                key={label}
                className="font-mono text-xs px-3 py-1 rounded-full"
                style={{
                  border: `0.5px solid ${colorMap[color].border}`,
                  color: colorMap[color].color,
                }}
              >
                {label}
              </span>
            ))}
          </div>
        </FadeIn>

      </div>
    </section>
  )
}