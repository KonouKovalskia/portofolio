'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'

const links = [
  {
    label: 'Email',
    value: 'your@email.com',
    href: 'mailto:your@email.com',
    accent: 'blue',
  },
  {
    label: 'WhatsApp',
    value: '+62 xxx xxxx xxxx',
    href: 'https://wa.me/62xxxxxxxxxx',
    accent: 'cyan',
  },
  {
    label: 'GitHub',
    value: 'github.com/yourhandle',
    href: 'https://github.com/yourhandle',
    accent: 'purple',
  },
  {
    label: 'LinkedIn',
    value: 'linkedin.com/in/yourhandle',
    href: 'https://linkedin.com/in/yourhandle',
    accent: 'blue',
  },
]

const colorMap = {
  blue: { border: 'rgba(79,195,247,0.2)', hover: 'rgba(79,195,247,0.4)', text: '#4FC3F7', bg: 'rgba(79,195,247,0.05)' },
  purple: { border: 'rgba(157,78,221,0.2)', hover: 'rgba(157,78,221,0.4)', text: '#9D4EDD', bg: 'rgba(157,78,221,0.05)' },
  cyan: { border: 'rgba(0,255,209,0.15)', hover: 'rgba(0,255,209,0.35)', text: '#00FFD1', bg: 'rgba(0,255,209,0.04)' },
}

export default function Contact() {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section
      id="contact"
      className="relative px-8 md:px-24 py-32 pb-16"
      style={{ borderTop: '0.5px solid rgba(79,195,247,0.1)' }}
    >
      {/* Nebula accent */}
      <div
        className="absolute left-1/2 bottom-0 pointer-events-none"
        style={{
          width: '600px',
          height: '300px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(79,195,247,0.04) 0%, transparent 70%)',
          transform: 'translateX(-50%)',
        }}
      />

      <div className="relative z-10 max-w-2xl">

        {/* Header */}
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-12"
        >
          <div className="flex items-center gap-3 mb-3">
            <span
              className="font-mono text-xs tracking-widest uppercase"
              style={{ color: '#00FFD1' }}
            >
              {"// contact"}
            </span>
          </div>
          <h2
            className="font-sora font-semibold mb-2"
            style={{ fontSize: '32px', letterSpacing: '-0.01em' }}
          >
            Get In Touch
          </h2>
          <div
            className="mb-6"
            style={{
              width: '40px',
              height: '1px',
              background: 'linear-gradient(90deg, #4FC3F7, #9D4EDD)',
            }}
          />
          <p
            className="font-sora font-light"
            style={{ fontSize: '15px', color: '#6b6b8a', lineHeight: 1.7 }}
          >
            Open to internships, collaborations, or just a chat.
            Pick your preferred channel below.
          </p>
        </motion.div>

        {/* Contact links */}
        <div className="grid grid-cols-2 gap-4 mb-20">
          {links.map(({ label, value, href, accent }, i) => {
            const c = colorMap[accent]
            return (
              <motion.a
                key={label}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.1 + i * 0.08 }}
                className="block rounded-xl p-4 no-underline transition-all duration-200"
                style={{
                  background: c.bg,
                  border: `0.5px solid ${c.border}`,
                  textDecoration: 'none',
                }}
                onMouseEnter={e => e.currentTarget.style.borderColor = c.hover}
                onMouseLeave={e => e.currentTarget.style.borderColor = c.border}
              >
                <div
                  className="font-mono text-xs tracking-widest uppercase mb-1"
                  style={{ color: c.text }}
                >
                  {label}
                </div>
                <div
                  className="font-sora text-sm truncate"
                  style={{ color: '#6b6b8a' }}
                >
                  {value}
                </div>
              </motion.a>
            )
          })}
        </div>

        {/* Footer bottom */}
        <div
          className="pt-8 flex items-center justify-between flex-wrap gap-4"
          style={{ borderTop: '0.5px solid rgba(79,195,247,0.1)' }}
        >
          <div
            className="font-mono text-xs tracking-wider"
            style={{ color: '#6b6b8a' }}
          >
            © 2026 Konou · Built with Next.js · Deployed on Vercel
          </div>
          <div
            className="font-mono text-xs"
            style={{ color: '#6b6b8a' }}
          >
            <span style={{ color: '#4FC3F7' }}>✦</span> Made in Indonesia
          </div>
        </div>

      </div>
    </section>
  )
}