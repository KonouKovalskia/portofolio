'use client'

import { motion } from 'framer-motion'

export default function Hero() {
  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section
      id="home"
      className="relative min-h-screen flex flex-col justify-between px-8 md:px-24"
    >
      {/* Glow blob */}
      <div
        className="absolute right-0 top-1/4 pointer-events-none"
        style={{
          width: '500px',
          height: '500px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(157,78,221,0.1) 0%, transparent 70%)',
        }}
      />

      {/* Main content */}
      <div className="flex items-center flex-1 relative z-10">
        <div className="max-w-2xl">

          {/* Tag */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex items-center gap-3 mb-6"
          >
            <div style={{ width: '24px', height: '1px', background: '#00FFD1' }} />
            <span
              className="font-mono text-xs tracking-widest uppercase"
              style={{ color: '#00FFD1' }}
            >
              Informatika · Telkom University
            </span>
          </motion.div>

          {/* Name */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="font-sora font-bold mb-4"
            style={{ fontSize: '56px', lineHeight: 1.1, letterSpacing: '-0.02em' }}
          >
            Hi, I&apos;m{' '}
            <span
              style={{
                background: 'linear-gradient(90deg, #4FC3F7, #9D4EDD)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              Konou
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="font-sora font-light mb-10"
            style={{ fontSize: '17px', color: '#6b6b8a', lineHeight: 1.7, maxWidth: '420px' }}
          >
            Building real products — from campus tools to business systems.
            Based in Bandung, Indonesia.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex gap-4 items-center"
          >
            <button
              onClick={() => scrollTo('projects')}
              className="font-sora font-semibold text-sm px-6 py-3 rounded-md cursor-pointer"
              style={{
                background: '#4FC3F7',
                color: '#05050f',
                border: 'none',
                transition: 'background 0.2s',
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#38b2e0'}
              onMouseLeave={e => e.currentTarget.style.background = '#4FC3F7'}
            >
              View Projects
            </button>

            <a
              href="/cv.pdf"
              download
              className="font-sora text-sm px-6 py-3 rounded-md"
              style={{
                background: 'transparent',
                color: '#4FC3F7',
                border: '0.5px solid #4FC3F7',
                textDecoration: 'none',
                transition: 'background 0.2s',
              }}
              onClick={e => {
                if (process.env.NODE_ENV === 'development') {
                  e.preventDefault()
                  alert('Drop cv.pdf into public/ folder first')
                }
              }}
              onMouseEnter={e => e.currentTarget.style.background = 'rgba(79,195,247,0.08)'}
              onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
            >
              Download CV
            </a>
          </motion.div>

        </div>
      </div>

      {/* Scroll hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1, delay: 1 }}
        className="relative z-10 flex items-center gap-3 pb-12"
        style={{ color: '#6b6b8a' }}
      >
        <div
          style={{
            width: '1px',
            height: '48px',
            background: 'linear-gradient(180deg, #4FC3F7, transparent)',
          }}
        />
        <span className="font-mono text-xs tracking-widest">scroll down</span>
      </motion.div>

    </section>
  )
}